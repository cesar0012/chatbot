// Variables globales
let editor;
let isDragging = false;
let dragStartTime = 0;
let lastDropTime = 0;
const DRAG_THROTTLE = 50; // ms entre operaciones de arrastre para mejorar rendimiento

// Referencia a los elementos del formulario (inicializados en initFlowEditor)
let flowNodesInput;
let flowConnectionsInput;

// Inicializar el editor de flujos
function initFlowEditor() {
    console.log('Inicializando editor de flujos');
    
    // Inicializar referencias a los elementos del formulario
    flowNodesInput = document.getElementById('flow_nodes');
    flowConnectionsInput = document.getElementById('flow_connections');
    
    if (!flowNodesInput || !flowConnectionsInput) {
        console.error('No se encontraron los elementos del formulario');
        return;
    }
    
    // Obtener los datos del flujo actual
    const flowId = document.getElementById('flow_id').value;
    const flowName = document.getElementById('flow_name').value;
    const flowDescription = document.getElementById('flow_description').value;
    
    console.log(`Inicializando flujo: ${flowName} (ID: ${flowId})`);
    
    // Obtener los nodos y conexiones
    let nodes = [];
    let connections = [];
    
    try {
        // Intentar parsear los nodos y conexiones si existen
        if (flowNodesInput.value && flowNodesInput.value !== '[]') {
            nodes = JSON.parse(flowNodesInput.value);
            console.log(`Cargando ${nodes.length} nodos existentes`);
        }
        
        if (flowConnectionsInput.value && flowConnectionsInput.value !== '[]') {
            connections = JSON.parse(flowConnectionsInput.value);
            console.log(`Cargando ${connections.length} conexiones existentes`);
        }
    } catch (e) {
        console.error('Error al parsear los datos del flujo:', e);
    }
    
    // Inicializar DrawFlow
    initDrawFlow(nodes, connections);
    
    // Configurar eventos de arrastre después de un pequeño retraso para asegurar que el DOM esté listo
    setTimeout(() => {
        setupDragEvents();
        console.log('Eventos de arrastre configurados');
    }, 300);
}

// Inicializar DrawFlow
function initDrawFlow(nodes = [], connections = []) {
    // Limpiar el contenedor
    const drawflowContainer = document.getElementById('drawflow');
    drawflowContainer.innerHTML = '';
    
    // Crear una nueva instancia de DrawFlow
    editor = new Drawflow(drawflowContainer);
    
    // Configurar el editor
    editor.reroute = true;
    editor.curvature = 0.5;
    editor.force_first_input = false;
    editor.zoom_max = 1.5;
    editor.zoom_min = 0.5;
    editor.zoom_value = 1;
    
    // Importante: Configurar el modo de conexión antes de iniciar
    editor.connectionMode = 'strict'; // Esto asegura que las conexiones sigan reglas estrictas
    
    // Iniciar el editor
    editor.start();
    
    // Configurar eventos del editor
    editor.on('nodeCreated', function(id) {
        console.log('Nodo creado:', id);
        // Añadir clases específicas al nodo recién creado
        const nodeElement = document.querySelector(`.drawflow-node[id="node-${id}"]`);
        if (nodeElement) {
            const nodeData = editor.getNodeFromId(id);
            if (nodeData) {
                nodeElement.classList.add(nodeData.name);
                console.log(`Clase ${nodeData.name} añadida al nodo ${id}`);
            }
        }
        updateFormData();
    });
    
    editor.on('nodeRemoved', function(id) {
        console.log('Nodo eliminado:', id);
        updateFormData();
    });
    
    editor.on('connectionCreated', function(connection) {
        console.log('Conexión creada:', connection);
        // Destacar visualmente la conexión creada
        setTimeout(() => {
            const connectionElement = document.querySelector(`.connection.node_in_${connection.input_id}.node_out_${connection.output_id}`);
            if (connectionElement) {
                connectionElement.classList.add('connection-active');
                setTimeout(() => {
                    connectionElement.classList.remove('connection-active');
                }, 1000);
            }
            updateFormData();
        }, 100);
    });
    
    editor.on('connectionRemoved', function(connection) {
        console.log('Conexión eliminada:', connection);
        updateFormData();
    });
    
    editor.on('mouseMove', function(position) {
        // Esto ayuda a mejorar la experiencia de conexión
        document.querySelectorAll('.drawflow .drawflow-node .input, .drawflow .drawflow-node .output').forEach(point => {
            point.classList.remove('connecting');
        });
    });
    
    editor.on('connectionStart', function(position) {
        console.log('Inicio de conexión');
        document.body.classList.add('connecting-mode');
        
        // Resaltar todos los puntos de conexión válidos
        document.querySelectorAll('.drawflow .drawflow-node .input').forEach(point => {
            point.classList.add('highlight-connection');
        });
    });
    
    editor.on('connectionCancel', function(position) {
        console.log('Conexión cancelada');
        document.body.classList.remove('connecting-mode');
        
        // Quitar resaltado de los puntos de conexión
        document.querySelectorAll('.drawflow .drawflow-node .input, .drawflow .drawflow-node .output').forEach(point => {
            point.classList.remove('highlight-connection');
        });
    });
    
    // Configurar el modo de conexión (ya configurado antes de iniciar)
    
    // Cargar nodos existentes
    if (nodes && nodes.length > 0) {
        // Crear los nodos
        nodes.forEach(node => {
            // Configurar inputs/outputs según el tipo de nodo
            let inputs = 0;
            let outputs = 0;
            
            switch(node.type) {
                case 'start':
                    inputs = 0;
                    outputs = 1;
                    break;
                case 'condition':
                    inputs = 1;
                    outputs = 2;
                    break;
                case 'action':
                    inputs = 1;
                    outputs = 1;
                    break;
            }
            
            // Añadir el nodo al editor
            editor.addNode(
                node.type,
                inputs,
                outputs,
                node.posX || 100,
                node.posY || 100,
                node.type,
                node.data || {},
                createNodeHTML(node.type, node.data)
            );
        });
    }
    
    // Cargar conexiones existentes después de un breve retraso
    if (connections && connections.length > 0) {
        setTimeout(() => {
            connections.forEach(conn => {
                try {
                    // Asegurar que los valores sean números
                    const sourceId = parseInt(conn.nodeSource);
                    const targetId = parseInt(conn.nodeTarget);
                    
                    // Determinar los índices de salida/entrada
                    let outputIndex = 0;
                    let inputIndex = 0;
                    
                    // Si hay información de outputSource, usarla
                    if (conn.outputSource !== null && conn.outputSource !== undefined) {
                        outputIndex = parseInt(conn.outputSource);
                    }
                    
                    // Si hay información de inputTarget, usarla
                    if (conn.inputTarget !== null && conn.inputTarget !== undefined) {
                        inputIndex = parseInt(conn.inputTarget);
                    }
                    
                    // Verificar que los nodos existan
                    if (editor.getNodeFromId(sourceId) && editor.getNodeFromId(targetId)) {
                        editor.addConnection(sourceId, targetId, outputIndex, inputIndex);
                    }
                } catch (error) {
                    console.error('Error al crear conexión:', error);
                }
            });
        }, 500);
    }
}

// Configurar eventos de arrastre
function setupDragEvents() {
    // Configurar eventos de arrastre para los nodos (una sola vez)
    // Buscar tanto las clases antiguas como las nuevas para compatibilidad
    const nodeItems = document.querySelectorAll('.node-item, .flow-node-item');
    
    console.log('Configurando eventos de arrastre para', nodeItems.length, 'elementos');
    
    // Eliminar eventos anteriores para evitar duplicados
    nodeItems.forEach(item => {
        item.removeEventListener('dragstart', handleDragStart);
        item.addEventListener('dragstart', handleDragStart);
        console.log('Evento dragstart configurado para', item.textContent.trim());
    });
    
    // Configurar el contenedor para recibir elementos
    const drawflowContainer = document.getElementById('drawflow');
    
    if (!drawflowContainer) {
        console.error('No se encontró el contenedor drawflow');
        return;
    }
    
    // Eliminar eventos anteriores para evitar duplicados
    drawflowContainer.removeEventListener('dragover', handleDragOver);
    drawflowContainer.removeEventListener('drop', handleDrop);
    
    // Añadir nuevos eventos
    drawflowContainer.addEventListener('dragover', handleDragOver);
    drawflowContainer.addEventListener('drop', handleDrop);
    console.log('Eventos dragover y drop configurados para el contenedor');
}

// Manejar el inicio del arrastre
function handleDragStart(e) {
    // Usar efectos de arrastre para mejor rendimiento
    e.dataTransfer.effectAllowed = 'copy';
    
    // Obtener el tipo de nodo
    const nodeType = this.getAttribute('data-node-type');
    console.log('Iniciando arrastre de tipo:', nodeType);
    
    if (!nodeType) {
        console.error('Error: No se pudo obtener el tipo de nodo');
        return;
    }
    
    // Guardar el tipo de nodo en el dataTransfer en múltiples formatos para mayor compatibilidad
    e.dataTransfer.setData('text/plain', nodeType);
    e.dataTransfer.setData('node-type', nodeType);
    e.dataTransfer.setData('application/json', JSON.stringify({type: nodeType}));
    
    try {
        // Establecer una imagen de arrastre personalizada para mejor feedback visual
        const dragIcon = document.createElement('div');
        dragIcon.className = `flow-node-item ${nodeType}`;
        dragIcon.style.width = '100px';
        dragIcon.style.height = '40px';
        dragIcon.style.borderRadius = '8px';
        dragIcon.style.opacity = '0.7';
        dragIcon.textContent = nodeType.charAt(0).toUpperCase() + nodeType.slice(1);
        document.body.appendChild(dragIcon);
        e.dataTransfer.setDragImage(dragIcon, 50, 20);
        setTimeout(() => document.body.removeChild(dragIcon), 0);
    } catch (error) {
        console.error('Error al crear imagen de arrastre:', error);
    }
    
    // Registrar el tiempo de inicio del arrastre
    dragStartTime = Date.now();
    
    // Añadir clase de arrastre para feedback visual
    this.classList.add('dragging');
    
    console.log('Datos de arrastre configurados:', nodeType);
}

// Manejar el evento dragover
function handleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    
    // Añadir indicador visual de dónde se soltará el elemento
    const drawflowContainer = document.getElementById('drawflow');
    drawflowContainer.classList.add('drag-over');
}

// Manejar el evento drop
function handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('Evento drop recibido');
    
    // Eliminar clase de arrastre
    const drawflowContainer = document.getElementById('drawflow');
    if (!drawflowContainer) {
        console.error('No se encontró el contenedor drawflow');
        return;
    }
    
    drawflowContainer.classList.remove('drag-over');
    document.querySelectorAll('.node-item, .flow-node-item').forEach(item => {
        item.classList.remove('dragging');
    });
    
    // Evitar múltiples operaciones de drop en un corto período
    const now = Date.now();
    if (now - lastDropTime < DRAG_THROTTLE) {
        console.log('Ignorando drop por throttle');
        return;
    }
    lastDropTime = now;
    
    // Si ya estamos en medio de una operación de arrastre, ignorar este evento
    if (isDragging) {
        console.log('Ignorando drop porque ya estamos arrastrando');
        return;
    }
    
    // Intentar obtener el tipo de nodo de diferentes formatos
    let nodeType = null;
    
    try {
        // Intentar obtener el tipo de nodo de diferentes formatos
        nodeType = e.dataTransfer.getData('text/plain');
        if (!nodeType) {
            nodeType = e.dataTransfer.getData('node-type');
        }
        
        // Intentar obtener desde JSON si los anteriores fallaron
        if (!nodeType) {
            const jsonData = e.dataTransfer.getData('application/json');
            if (jsonData) {
                const data = JSON.parse(jsonData);
                nodeType = data.type;
            }
        }
        
        // Último recurso: intentar obtener el tipo desde el elemento que se está arrastrando
        if (!nodeType) {
            const draggingElement = document.querySelector('.dragging');
            if (draggingElement) {
                nodeType = draggingElement.getAttribute('data-node-type');
            }
        }
    } catch (error) {
        console.error('Error al obtener el tipo de nodo:', error);
    }
    
    console.log('Tipo de nodo recibido en drop:', nodeType);
    
    if (nodeType) {
        // Marcar que estamos en proceso de arrastre
        isDragging = true;
        
        const rect = drawflowContainer.getBoundingClientRect();
        const posX = e.clientX - rect.left;
        const posY = e.clientY - rect.top;
        
        console.log('Posición del drop:', posX, posY);
        
        // Añadir el nodo con un pequeño retraso para asegurar que el DOM esté listo
        setTimeout(() => {
            // Añadir el nodo
            const nodeId = addNode(nodeType, posX, posY);
            console.log(`Nodo añadido con ID: ${nodeId}`);
            
            // Restablecer el estado de arrastre
            isDragging = false;
            console.log('Estado de arrastre restablecido');
        }, 50);
    } else {
        console.error('No se pudo obtener el tipo de nodo del evento drop');
    }
}

// Función para añadir un nodo al editor
function addNode(type, posX, posY) {
    console.log(`Añadiendo nodo de tipo: ${type} en posición (${posX}, ${posY})`);
    
    // Configurar entradas y salidas según el tipo de nodo
    let inputs = 0;
    let outputs = 0;
    let data = {};
    
    switch(type) {
        case 'start':
            inputs = 0;
            outputs = 1;
            data = { name: 'Inicio', description: 'Punto de entrada del flujo' };
            break;
        case 'condition':
            inputs = 1;
            outputs = 2;
            data = { 
                name: 'Condición', 
                condition_text: '', 
                condition_type: 'text',
                output_labels: ['Verdadero', 'Falso']
            };
            break;
        case 'action':
            inputs = 1;
            outputs = 1;
            data = { 
                name: 'Acción', 
                action_type: 'message', 
                action_content: '' 
            };
            break;
        default:
            console.error('Tipo de nodo desconocido:', type);
            return null;
    }
    
    try {
        // Añadir el nodo al editor
        const nodeId = editor.addNode(
            type,           // Tipo de nodo
            inputs,         // Número de entradas
            outputs,        // Número de salidas
            posX,           // Posición X
            posY,           // Posición Y
            type,           // Clase CSS
            data,           // Datos iniciales
            createNodeHTML(type, data)  // Contenido HTML
        );
        
        console.log(`Nodo añadido con éxito, ID: ${nodeId}, Tipo: ${type}`);
        
        // Aplicar estilos específicos al nodo recién creado
        const nodeElement = document.querySelector(`.drawflow-node[id="node-${nodeId}"]`);
        if (nodeElement) {
            // Añadir clase para estilos específicos
            nodeElement.classList.add(type);
            
            // Mejorar la visibilidad de los puntos de conexión
            const inputs = nodeElement.querySelectorAll('.input');
            const outputs = nodeElement.querySelectorAll('.output');
            
            inputs.forEach((input, index) => {
                input.setAttribute('title', 'Conectar entrada');
                input.classList.add('input-point');
            });
            
            outputs.forEach((output, index) => {
                let title = 'Conectar salida';
                if (type === 'condition' && data.output_labels && data.output_labels[index]) {
                    title = data.output_labels[index];
                }
                output.setAttribute('title', title);
                output.classList.add('output-point');
                output.classList.add(`output-${index}`);
            });
            
            console.log(`Estilos aplicados al nodo ${nodeId}`);
        } else {
            console.error(`No se pudo encontrar el elemento del nodo ${nodeId}`);
        }
        
        // Actualizar el formulario con los nuevos datos
        setTimeout(updateFormData, 100);
        
        return nodeId;
    } catch (error) {
        console.error('Error al añadir nodo:', error);
        return null;
    }
}

// Crear HTML para cada tipo de nodo
function createNodeHTML(type, data = {}) {
    console.log('Creando HTML para nodo de tipo:', type);
    let title = '';
    let icon = '';
    let content = '';
    
    switch(type) {
        case 'start':
            title = 'Inicio del Flujo';
            icon = '<i class="fas fa-play-circle"></i>';
            content = '<p class="small text-muted">Punto de entrada del flujo</p>';
            break;
        case 'condition':
            title = 'Condición';
            icon = '<i class="fas fa-code-branch"></i>';
            content = `
                <div class="flow-node-form">
                    <div class="flow-form-group">
                        <label>Condición:</label>
                        <input type="text" placeholder="Condición a evaluar" class="form-control form-control-sm condition-text" value="${data.condition_text || ''}">
                    </div>
                    <div class="flow-form-group">
                        <label>Tipo:</label>
                        <select class="form-select form-select-sm condition-type">
                            <option value="text" ${data.condition_type === 'text' ? 'selected' : ''}>Texto exacto</option>
                            <option value="contains" ${data.condition_type === 'contains' ? 'selected' : ''}>Contiene texto</option>
                            <option value="ai" ${data.condition_type === 'ai' ? 'selected' : ''}>Evaluación con IA</option>
                        </select>
                    </div>
                    <div class="outputs-label mt-2">
                        <div><span class="badge bg-success">Verdadero</span> <i class="fas fa-arrow-right"></i></div>
                        <div><span class="badge bg-danger">Falso</span> <i class="fas fa-arrow-right"></i></div>
                    </div>
                </div>
            `;
            break;
        case 'action':
            title = 'Acción';
            icon = '<i class="fas fa-bolt"></i>';
            content = `
                <div class="flow-node-form">
                    <div class="flow-form-group">
                        <label>Tipo:</label>
                        <select class="form-select form-select-sm action-type">
                            <option value="message" ${data.action_type === 'message' ? 'selected' : ''}>Enviar mensaje</option>
                            <option value="redirect" ${data.action_type === 'redirect' ? 'selected' : ''}>Redireccionar</option>
                            <option value="api" ${data.action_type === 'api' ? 'selected' : ''}>Llamar API</option>
                            <option value="function" ${data.action_type === 'function' ? 'selected' : ''}>Ejecutar función</option>
                        </select>
                    </div>
                    <div class="flow-form-group">
                        <label>Contenido:</label>
                        <textarea placeholder="Contenido de la acción" class="form-control form-control-sm action-content" rows="2">${data.action_content || ''}</textarea>
                    </div>
                </div>
            `;
            break;
    }
    
    return `
        <div class="flow-node-content">
            <div class="flow-node-header">${icon} ${title}</div>
            ${content}
        </div>
    `;
}

// Actualizar los datos del formulario con el estado actual del editor
function updateFormData() {
    console.log('Actualizando datos del formulario');
    
    // Verificar que el editor esté inicializado
    if (!editor) {
        console.error('Editor no inicializado');
        return;
    }
    
    // Obtener referencias a los elementos del formulario si no están inicializados
    if (!flowNodesInput) {
        flowNodesInput = document.getElementById('flow_nodes');
        if (!flowNodesInput) {
            console.error('No se encontró el elemento flow_nodes');
            return;
        }
    }
    
    if (!flowConnectionsInput) {
        flowConnectionsInput = document.getElementById('flow_connections');
        if (!flowConnectionsInput) {
            console.error('No se encontró el elemento flow_connections');
            return;
        }
    }
    
    // Exportar datos del editor
    const editorData = editor.export();
    console.log('Datos exportados del editor:', editorData);
    
    const nodes = [];
    const connections = [];
    
    // Extraer nodos y sus datos
    if (editorData.drawflow && editorData.drawflow.Home && editorData.drawflow.Home.data) {
        Object.values(editorData.drawflow.Home.data).forEach(node => {
            // Recopilar datos de los formularios dentro de los nodos
            const nodeElement = document.querySelector(`[id="node-${node.id}"]`);
            let nodeData = {};
            
            // Preservar los datos existentes del nodo
            if (node.data) {
                nodeData = { ...node.data };
            }
            
            // Actualizar con los valores actuales de los formularios
            if (nodeElement) {
                if (node.name === 'condition') {
                    const conditionText = nodeElement.querySelector('.condition-text');
                    const conditionType = nodeElement.querySelector('.condition-type');
                    if (conditionText) nodeData.condition_text = conditionText.value;
                    if (conditionType) nodeData.condition_type = conditionType.value;
                } else if (node.name === 'action') {
                    const actionType = nodeElement.querySelector('.action-type');
                    const actionContent = nodeElement.querySelector('.action-content');
                    if (actionType) nodeData.action_type = actionType.value;
                    if (actionContent) nodeData.action_content = actionContent.value;
                }
            }
            
            // Guardar el nodo
            nodes.push({
                id: node.id,
                type: node.name,
                posX: node.pos_x,
                posY: node.pos_y,
                data: nodeData
            });
            
            // Extraer conexiones
            if (node.outputs) {
                Object.entries(node.outputs).forEach(([outputIndex, output]) => {
                    if (output.connections && output.connections.length > 0) {
                        output.connections.forEach(conn => {
                            connections.push({
                                nodeSource: node.id,
                                nodeTarget: conn.node,
                                outputSource: parseInt(outputIndex),
                                inputTarget: conn.input
                            });
                        });
                    }
                });
            }
        });
    }
    
    console.log('Nodos procesados:', nodes.length);
    console.log('Conexiones procesadas:', connections.length);
    
    // Actualizar los campos ocultos del formulario
    flowNodesInput.value = JSON.stringify(nodes);
    flowConnectionsInput.value = JSON.stringify(connections);
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM cargado, configurando eventos iniciales');
    
    // Configurar cerrar modal
    document.querySelectorAll('.close-modal, .close-modal-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const modals = document.querySelectorAll('.flow-editor-modal, .modal');
            modals.forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });
    
    // Inicializar el editor cuando se abra el modal
    const createFlowBtn = document.getElementById('create-flow-btn');
    if (createFlowBtn) {
        createFlowBtn.addEventListener('click', function() {
            console.log('Botón crear flujo clickeado');
            document.getElementById('flow-editor-modal').style.display = 'block';
            setTimeout(() => {
                initFlowEditor();
            }, 100);
        });
    }
    
    // Inicializar el editor cuando se edite un flujo existente
    document.querySelectorAll('.edit-flow-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            console.log('Botón editar flujo clickeado');
            document.getElementById('flow-editor-modal').style.display = 'block';
            setTimeout(() => {
                initFlowEditor();
            }, 100);
        });
    });
});
