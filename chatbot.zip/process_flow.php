<?php
/**
 * Clase para procesar flujos de conversación
 * 
 * Esta clase maneja la lógica de los flujos de conversación definidos por el usuario
 * Evalúa condiciones y ejecuta acciones basadas en el mensaje del usuario
 */
class FlowProcessor {
    private $flows = [];
    private $activeFlow = null;
    private $activeNode = null;
    private $sessionId;
    private $geminiApiKey;
    
    /**
     * Constructor
     * 
     * @param string $sessionId ID de la sesión actual
     * @param string $geminiApiKey Clave de API de Gemini para evaluación de condiciones
     */
    public function __construct($sessionId, $geminiApiKey) {
        $this->sessionId = $sessionId;
        $this->geminiApiKey = $geminiApiKey;
        $this->loadFlows();
        $this->loadActiveFlow();
    }
    
    /**
     * Cargar todos los flujos disponibles
     */
    private function loadFlows() {
        $flows_dir = "memory-bank/flows/";
        if (file_exists($flows_dir) && is_dir($flows_dir)) {
            $flow_files = glob($flows_dir . "*.json");
            foreach ($flow_files as $flow_file) {
                $flow_data = json_decode(file_get_contents($flow_file), true);
                if ($flow_data) {
                    $this->flows[basename($flow_file, '.json')] = $flow_data;
                }
            }
        }
    }
    
    /**
     * Cargar el flujo activo de la sesión
     */
    private function loadActiveFlow() {
        $flow_state_file = "memory-bank/flow_state_{$this->sessionId}.json";
        if (file_exists($flow_state_file)) {
            $flow_state = json_decode(file_get_contents($flow_state_file), true);
            if ($flow_state && isset($flow_state['active_flow']) && isset($flow_state['active_node'])) {
                $this->activeFlow = $flow_state['active_flow'];
                $this->activeNode = $flow_state['active_node'];
            }
        }
    }
    
    /**
     * Guardar el estado del flujo activo
     */
    private function saveActiveFlow() {
        $flow_state_file = "memory-bank/flow_state_{$this->sessionId}.json";
        $flow_state = [
            'active_flow' => $this->activeFlow,
            'active_node' => $this->activeNode,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        file_put_contents($flow_state_file, json_encode($flow_state, JSON_PRETTY_PRINT));
    }
    
    /**
     * Procesar un mensaje del usuario a través de los flujos
     * 
     * @param string $userMessage Mensaje del usuario
     * @return array Resultado del procesamiento con acción y contenido
     */
    public function processMessage($userMessage) {
        $result = [
            'action' => 'none',
            'content' => null,
            'flow_processed' => false
        ];
        
        // Si no hay flujo activo, buscar un flujo que pueda iniciarse
        if ($this->activeFlow === null) {
            foreach ($this->flows as $flowId => $flow) {
                $startNode = $this->findStartNode($flow);
                if ($startNode) {
                    $this->activeFlow = $flowId;
                    $this->activeNode = $startNode['id'];
                    $this->saveActiveFlow();
                    break;
                }
            }
        }
        
        // Si hay un flujo activo, procesar el nodo actual
        if ($this->activeFlow !== null && isset($this->flows[$this->activeFlow])) {
            $currentFlow = $this->flows[$this->activeFlow];
            $currentNode = $this->findNodeById($currentFlow, $this->activeNode);
            
            if ($currentNode) {
                // Procesar según el tipo de nodo
                switch ($currentNode['type']) {
                    case 'start':
                        // Buscar el siguiente nodo conectado al inicio
                        $nextNode = $this->findNextNode($currentFlow, $currentNode['id'], 0);
                        if ($nextNode) {
                            $this->activeNode = $nextNode;
                            $this->saveActiveFlow();
                            // Procesar inmediatamente el siguiente nodo
                            return $this->processMessage($userMessage);
                        }
                        break;
                        
                    case 'condition':
                        // Evaluar la condición
                        $conditionResult = $this->evaluateCondition($currentNode, $userMessage);
                        // Buscar el siguiente nodo según el resultado (0 para verdadero, 1 para falso)
                        $outputIndex = $conditionResult ? 0 : 1;
                        $nextNode = $this->findNextNode($currentFlow, $currentNode['id'], $outputIndex);
                        
                        if ($nextNode) {
                            $this->activeNode = $nextNode;
                            $this->saveActiveFlow();
                            $result['flow_processed'] = true;
                            // Procesar inmediatamente el siguiente nodo
                            return $this->processMessage($userMessage);
                        }
                        break;
                        
                    case 'action':
                        // Ejecutar la acción
                        $actionResult = $this->executeAction($currentNode);
                        $result['action'] = $actionResult['action'];
                        $result['content'] = $actionResult['content'];
                        $result['flow_processed'] = true;
                        
                        // Buscar el siguiente nodo
                        $nextNode = $this->findNextNode($currentFlow, $currentNode['id'], 0);
                        if ($nextNode) {
                            $this->activeNode = $nextNode;
                        } else {
                            // Si no hay siguiente nodo, finalizar el flujo
                            $this->activeFlow = null;
                            $this->activeNode = null;
                        }
                        $this->saveActiveFlow();
                        break;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Encontrar el nodo de inicio en un flujo
     * 
     * @param array $flow Datos del flujo
     * @return array|null Nodo de inicio o null si no se encuentra
     */
    private function findStartNode($flow) {
        if (isset($flow['nodes'])) {
            foreach ($flow['nodes'] as $node) {
                if ($node['type'] === 'start') {
                    return $node;
                }
            }
        }
        return null;
    }
    
    /**
     * Encontrar un nodo por su ID
     * 
     * @param array $flow Datos del flujo
     * @param int $nodeId ID del nodo a buscar
     * @return array|null Nodo encontrado o null si no existe
     */
    private function findNodeById($flow, $nodeId) {
        if (isset($flow['nodes'])) {
            foreach ($flow['nodes'] as $node) {
                if ($node['id'] == $nodeId) {
                    return $node;
                }
            }
        }
        return null;
    }
    
    /**
     * Encontrar el siguiente nodo conectado
     * 
     * @param array $flow Datos del flujo
     * @param int $currentNodeId ID del nodo actual
     * @param int $outputIndex Índice de la salida (0 para verdadero, 1 para falso en condiciones)
     * @return int|null ID del siguiente nodo o null si no hay conexión
     */
    private function findNextNode($flow, $currentNodeId, $outputIndex) {
        if (isset($flow['connections'])) {
            foreach ($flow['connections'] as $connection) {
                if ($connection['nodeSource'] == $currentNodeId && $connection['outputSource'] == $outputIndex) {
                    return $connection['nodeTarget'];
                }
            }
        }
        return null;
    }
    
    /**
     * Evaluar una condición
     * 
     * @param array $node Nodo de condición
     * @param string $userMessage Mensaje del usuario
     * @return bool Resultado de la evaluación
     */
    private function evaluateCondition($node, $userMessage) {
        $conditionType = isset($node['data']['condition_type']) ? $node['data']['condition_type'] : 'text';
        $conditionText = isset($node['data']['condition_text']) ? $node['data']['condition_text'] : '';
        
        switch ($conditionType) {
            case 'text':
                // Comparación exacta de texto
                return strtolower(trim($userMessage)) === strtolower(trim($conditionText));
                
            case 'contains':
                // Verificar si el mensaje contiene el texto
                return stripos($userMessage, $conditionText) !== false;
                
            case 'ai':
                // Usar Gemini para evaluar la condición
                return $this->evaluateWithGemini($conditionText, $userMessage);
                
            default:
                return false;
        }
    }
    
    /**
     * Evaluar una condición usando la API de Gemini
     * 
     * @param string $condition Condición a evaluar
     * @param string $userMessage Mensaje del usuario
     * @return bool Resultado de la evaluación
     */
    private function evaluateWithGemini($condition, $userMessage) {
        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-04-17:generateContent?key={$this->geminiApiKey}";
        
        $prompt = "Evalúa la siguiente condición y responde SOLO con 'true' o 'false'.\n\n";
        $prompt .= "Condición a evaluar: $condition\n";
        $prompt .= "Mensaje del usuario: $userMessage\n\n";
        $prompt .= "Responde únicamente con 'true' si la condición se cumple o 'false' si no se cumple.";
        
        $data = [
            "contents" => [
                [
                    "parts" => [
                        ["text" => $prompt]
                    ]
                ]
            ],
            "generationConfig" => [
                "temperature" => 0,
                "maxOutputTokens" => 10,
                "topP" => 1,
                "topK" => 1
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $responseData = json_decode($response, true);
            if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
                $result = strtolower(trim($responseData['candidates'][0]['content']['parts'][0]['text']));
                return $result === 'true';
            }
        }
        
        // Por defecto, devolver falso si hay algún error
        return false;
    }
    
    /**
     * Ejecutar una acción
     * 
     * @param array $node Nodo de acción
     * @return array Resultado de la acción
     */
    private function executeAction($node) {
        $actionType = isset($node['data']['action_type']) ? $node['data']['action_type'] : 'message';
        $actionContent = isset($node['data']['action_content']) ? $node['data']['action_content'] : '';
        
        $result = [
            'action' => $actionType,
            'content' => $actionContent
        ];
        
        return $result;
    }
}
?>
