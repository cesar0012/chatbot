<?php
session_start();

// Incluir el procesador de flujos
require_once 'process_flow.php';

// Establecer la codificación UTF-8
header('Content-Type: application/json; charset=utf-8');

// Verificar que la solicitud sea POST y de tipo JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener el contenido JSON de la solicitud
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Verificar que se recibió un mensaje
    if (isset($data['message'])) {
        $userMessage = $data['message'];
        
        // Clase para manejar la conversación y almacenar el historial
        class TinyDB {
            private $dbFile;
            private $data;
            
            public function __construct($sessionId) {
                $this->dbFile = "memory-bank/conversation_$sessionId.json";
                $this->loadData();
            }
            
            private function loadData() {
                if (file_exists($this->dbFile)) {
                    $content = file_get_contents($this->dbFile);
                    $this->data = json_decode($content, true) ?: ['messages' => []];
                } else {
                    $this->data = ['messages' => []];
                }
            }
            
            public function saveData() {
                $dir = dirname($this->dbFile);
                if (!file_exists($dir)) {
                    mkdir($dir, 0777, true);
                }
                file_put_contents($this->dbFile, json_encode($this->data, JSON_PRETTY_PRINT));
            }
            
            public function addMessage($role, $content) {
                $this->data['messages'][] = [
                    'role' => $role,
                    'content' => $content,
                    'timestamp' => time()
                ];
                $this->saveData();
            }
            
            public function getMessages($limit = 10) {
                // Obtener los últimos X mensajes para contexto
                $messages = array_slice($this->data['messages'], -$limit);
                return $messages;
            }
        }
        
        // Función para cargar el contenido de los archivos de referencia
        function loadReferenceFiles() {
            $content = "";
            $dir = "memory-bank/";
            
            if (file_exists($dir) && is_dir($dir)) {
                $files = array_diff(scandir($dir), array('..', '.'));
                
                // Organizar archivos por tipo
                $instructions = [];
                $urls = [];
                $documents = [];
                $csvFiles = [];
                
                foreach ($files as $file) {
                    if (is_file($dir . $file) && !strpos($file, 'conversation_')) {
                        $fileExt = strtolower(pathinfo($dir . $file, PATHINFO_EXTENSION));
                        
                        if ($file === 'instructions.txt') {
                            $instructions[] = $file;
                        } elseif (strpos($file, 'url_') === 0) {
                            $urls[] = $file;
                        } elseif ($fileExt === 'csv') {
                            $csvFiles[] = $file;
                        } else {
                            $documents[] = $file;
                        }
                    }
                }
                
                // Procesar instrucciones primero (aunque normalmente no se incluyen en el contexto)
                foreach ($instructions as $file) {
                    // Las instrucciones se procesan por separado, no las incluimos aquí
                }
                
                // Procesar URLs extraídas
                if (!empty($urls)) {
                    $content .= "\n\n=== CONTENIDO DE URLS EXTRAÍDAS ===\n";
                    foreach ($urls as $file) {
                        $fileContent = file_get_contents($dir . $file);
                        // Extraer la URL original del contenido
                        $urlLine = strtok($fileContent, "\n");
                        $url = str_replace("URL: ", "", $urlLine);
                        
                        $content .= "\n--- Contenido de $url ---\n";
                        // Omitir la primera línea (URL) y agregar el resto
                        $content .= substr($fileContent, strpos($fileContent, "\n\n") + 2);
                    }
                }
                
                // Procesar archivos CSV
                if (!empty($csvFiles)) {
                    $content .= "\n\n=== CONTENIDO DE ARCHIVOS CSV ===\n";
                    foreach ($csvFiles as $file) {
                        $content .= "\n--- Contenido de $file ---\n";
                        
                        // Leer el archivo CSV y formatearlo para mejor legibilidad
                        $csvData = [];
                        if (($handle = fopen($dir . $file, "r")) !== FALSE) {
                            // Leer encabezados
                            $headers = fgetcsv($handle, 1000, ",");
                            $headerCount = count($headers);
                            
                            // Leer datos
                            $rowCount = 0;
                            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE && $rowCount < 100) { // Limitar a 100 filas para evitar prompts muy grandes
                                $csvData[] = $data;
                                $rowCount++;
                            }
                            fclose($handle);
                            
                            // Formatear datos para el prompt
                            $content .= "Encabezados: " . implode(", ", $headers) . "\n\n";
                            $content .= "Datos (mostrando hasta 100 filas):\n";
                            
                            foreach ($csvData as $row) {
                                $formattedRow = [];
                                for ($i = 0; $i < $headerCount && $i < count($row); $i++) {
                                    $formattedRow[] = $headers[$i] . ": " . $row[$i];
                                }
                                $content .= implode(" | ", $formattedRow) . "\n";
                            }
                            
                            if ($rowCount >= 100) {
                                $content .= "\n[Nota: Este archivo contiene más de 100 filas. Solo se muestran las primeras 100.]\n";
                            }
                        } else {
                            $content .= "Error al leer el archivo CSV.\n";
                        }
                    }
                }
                
                // Procesar documentos subidos
                if (!empty($documents)) {
                    $content .= "\n\n=== CONTENIDO DE DOCUMENTOS ===\n";
                    foreach ($documents as $file) {
                        $fileContent = file_get_contents($dir . $file);
                        $content .= "\n--- Contenido de $file ---\n";
                        $content .= $fileContent;
                    }
                }
            }
            
            return $content;
        }
        
        // Inicializar TinyDB con ID de sesión único
        $sessionId = session_id();
        $db = new TinyDB($sessionId);
        
        // Agregar mensaje del usuario a la base de datos
        $db->addMessage('user', $userMessage);
        
        // Cargar contenido de archivos de referencia
        $referenceContent = loadReferenceFiles();
        
        // Preparar el contexto para la API de Gemini
        $conversationHistory = $db->getMessages();
        $conversationText = "";
        
        foreach ($conversationHistory as $msg) {
            $role = $msg['role'] === 'user' ? 'Usuario' : 'Asistente';
            $conversationText .= "$role: {$msg['content']}\n";
        }
        
        // Construir el prompt para Gemini
        $prompt = "";
        
        // Agregar contexto de archivos de referencia si existe
        if (!empty($referenceContent)) {
            $prompt .= "Información de referencia disponible:\n$referenceContent\n\n";
        }
        
        // Agregar historial de conversación
        $prompt .= "Historial de conversación reciente:\n$conversationText\n";
        
        // Cargar instrucciones personalizadas si existen
        $customInstructions = "";
        $instructionsFile = "memory-bank/instructions.txt";
        if (file_exists($instructionsFile)) {
            $customInstructions = file_get_contents($instructionsFile);
        }
        
        // Agregar instrucciones para el modelo
        $prompt .= "\nEres un asistente virtual amigable y servicial. ";
        
        // Agregar instrucciones personalizadas si existen
        if (!empty($customInstructions)) {
            $prompt .= "$customInstructions \n";
        } else {
            $prompt .= "Responde de manera concisa y útil basándote en la información de referencia proporcionada cuando sea relevante. Si no conoces la respuesta, indícalo honestamente.\n";
        }
        
        $prompt .= "\n";
        
        // Agregar la pregunta actual
        $prompt .= "Usuario: $userMessage\nAsistente:";
        
        // Configuración de la API de Gemini
        $apiKey = "AIzaSyDhU-jRhCEDmd5xV2YSR1_7ifCiY_efbqQ"; // Reemplazar con tu API key real
        
        // Procesar flujos de conversación si existen
        $sessionId = session_id();
        $flowProcessor = new FlowProcessor($sessionId, $apiKey);
        $flowResult = $flowProcessor->processMessage($userMessage);
        
        // Si el flujo ha procesado el mensaje y generado una respuesta
        if ($flowResult['flow_processed'] && $flowResult['action'] !== 'none') {
            $botResponse = '';
            
            // Manejar diferentes tipos de acciones
            switch ($flowResult['action']) {
                case 'message':
                    // Respuesta directa del flujo
                    $botResponse = $flowResult['content'];
                    break;
                    
                case 'redirect':
                    // Redirección a otra página
                    $botResponse = "Te voy a redireccionar a: " . $flowResult['content'];
                    // Guardar la URL de redirección en la sesión para que el frontend la procese
                    $_SESSION['redirect_url'] = $flowResult['content'];
                    break;
                    
                case 'api':
                    // Llamada a una API externa
                    $botResponse = "Estoy procesando tu solicitud...";
                    // Aquí se podría implementar la lógica para llamar a una API externa
                    break;
                    
                case 'function':
                    // Ejecutar una función personalizada
                    $botResponse = "Ejecutando función personalizada...";
                    // Aquí se podría implementar la lógica para ejecutar funciones personalizadas
                    break;
                    
                default:
                    // Usar Gemini para generar una respuesta
                    $botResponse = "No entiendo qué acción realizar.";
            }
            
            // Guardar la respuesta en la base de datos
            $db->addMessage('assistant', $botResponse);
            
            // Devolver la respuesta como JSON
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'response' => $botResponse,
                'flow_action' => $flowResult['action'],
                'flow_data' => $flowResult['content']
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
        
        // Si no hay flujo activo o el flujo no generó una respuesta, usar Gemini
        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-04-17:generateContent?key=$apiKey";
        
        $data = [
            "contents" => [
                [
                    "parts" => [
                        ["text" => $prompt]
                    ]
                ]
            ],
            "generationConfig" => [
                "temperature" => 0.7,
                "maxOutputTokens" => 65536,
                "topP" => 0.95,
                "topK" => 40
            ]
        ];
        
        // Inicializar cURL
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        
        // Ejecutar la solicitud
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // Procesar la respuesta
        if ($httpCode === 200) {
            $responseData = json_decode($response, true);
            
            // Extraer el texto de la respuesta
            if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
                $botResponse = $responseData['candidates'][0]['content']['parts'][0]['text'];
                
                // Limpiar la respuesta si es necesario
                $botResponse = trim($botResponse);
                
                // Corregir problemas comunes con etiquetas HTML mal escapadas
                $botResponse = str_replace('\/', '/', $botResponse);
                
                // Asegurar que los caracteres especiales se codifiquen correctamente
                // Guardar la respuesta en la base de datos
                $db->addMessage('assistant', $botResponse);
                
                // Devolver la respuesta como JSON con la codificación UTF-8 correcta
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['response' => $botResponse], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                exit;
            }
        }
        
        // Si llegamos aquí, hubo un error
        echo json_encode([
            'response' => 'Lo siento, no pude procesar tu mensaje en este momento. Por favor, intenta de nuevo más tarde.'
        ]);
        exit;
    }
}

// Si llegamos aquí, la solicitud no es válida
http_response_code(400);
echo json_encode(['error' => 'Solicitud inválida']);
?>