<?php
session_start();

// Redirigir a la interfaz de usuario del chatbot
header("Location: chatbot.php");
exit;
?>